# Lag one autoregression
require(OpenMx)
data(demoOneFactor)
nvar <- ncol(demoOneFactor)
unam <- colnames(demoOneFactor)

amat <- mxMatrix("Full", 1, 1, TRUE, .3, name="A", labels="a11")
bmat <- mxMatrix("Zero", 1, 1, name="B")
clab <- paste("load", 1:nvar, sep="")
cdim <- list(unam, "F1")
cmat <- mxMatrix("Full", nvar, 1, TRUE, .6, name="C",
    dimnames=cdim, labels=clab)
dmat <- mxMatrix("Zero", nvar, 1, name="D")
qmat <- mxMatrix("Diag", 1, 1, FALSE, 1, name="Q")
rlab <- paste("resid", 1:nvar, sep="")
rmat <- mxMatrix("Diag", nvar, nvar, TRUE, .2, name="R", labels=rlab)
xmat <- mxMatrix("Zero", 1, 1, name="x0")
pmat <- mxMatrix("Diag", 1, 1, FALSE, 1, name="P0")
umat <- mxMatrix("Zero", 1, 1, name="u")

ssModel <- mxModel(model="Lag1LAR",
    amat, bmat, cmat, dmat, qmat, rmat, xmat, pmat, umat, 
    mxData(observed=demoOneFactor, type="raw"),
    mxExpectationStateSpace("A", "B", "C", "D", "Q", "R", "x0", "P0", "u"),
    mxFitFunctionML()
)
ssRun <- mxRun(ssModel)
summary(ssRun)

mkfm6Est <- c(0.07532, 0.3976, 0.50384, 0.57772, 0.70211, 0.79681, 0.04076, 0.03791, 0.04074, 0.03954, 0.03613)
mkfm6SEs <- c(0.0455, 0.0155, 0.0182, 0.0204, 0.0240, 0.0266, 0.0028, 0.0028, 0.0031, 0.0034, 0.0037)

r1 <- summary(ssRun)$parameters[,1:6]
r2 <- cbind(r1, MKFM6Est=mkfm6Est, MKFM6SEs=mkfm6SEs)
require(knitr)
kable(r2, digits=4, format='latex')


# Create new data set with times of observations 'ObsTime'
dataCT <- data.frame(demoOneFactor, ObsTime=seq(0.02, by=0.02, length.out=nrow(demoOneFactor)))

# Create continuous time version of the same model
# overwrites the discrete time expectation with a continuous time one
ssctModel <- mxModel(name="CTLag1LAR",
    model=ssModel,
    mxMatrix(name='Time', nrow=1, ncol=1, labels='data.ObsTime'),
    mxMatrix("Diag", 1, 1, FALSE, 129*2, name="Q"),
    mxData(observed=dataCT, type="raw"),
    mxExpectationStateSpaceContinuousTime("A", "B", "C", "D", "Q", "R", "x0", "P0", "u", t="Time")
)
ssctRun <- mxRun(ssctModel)
summary(ssctRun)

# Compare parameters of discrete and continuous time models
cbind(coef(ssRun), coef(ssctRun))


# Use mxSE and create a transformed model for the residual variances
rlab2 <- paste("logResid", 1:nvar, sep="")
rmat2 <- mxMatrix("Full", nvar, 1, TRUE, .2, name="logr", labels=rlab2)
ralg <- mxAlgebra(vec2diag(exp(logr)), name='R')

ssModel2 <- mxModel(model=ssModel,
    name="TransformedLagOneLatentAutoregression",
    "R", remove=TRUE
)
ssModel2 <- mxModel(model=ssModel2,
    rmat2, ralg
)
ssRun2 <- mxRun(ssModel2)
summary(ssRun2)

# Estimates and standard errors of the "working" parameters
(wp <- mxEval(logr, ssRun2))
(wse <- mxSE(logr, ssRun2))

# Estimates and standard errors of the "natural" parameters
(np <- mxEval(diag2vec(R), ssRun2))
(nse <- mxSE(diag2vec(R), ssRun2))

# Standard errors for parameters from the orignal model
(op <- mxEval(diag2vec(R), ssRun))
(ose <- mxSE(diag2vec(R), ssRun))

require(knitr)
kable(cbind(WorkingP=wp, WorkingSE=wse, NaturalP=np, NaturalSE=nse, OriginalP=op, OriginalSE=ose), digits=5, format='latex')


# Use mxCompare for nested models
ssZero <- mxModel(ssModel, name='Lag0LAR',
    mxMatrix("Zero", 1, 1, name="A")
)
ssZeroRun <- mxRun(ssZero)
mxCompare(ssRun, ssZeroRun)

# Use profile likelihood confidence intervals for the same hypothesis
ssCI <- mxModel(ssModel,
    mxCI("A")
)
ssCIRun <- mxRun(ssCI, intervals=TRUE)
summary(ssCIRun)

# Get Kalman scores from run model
scores <- mxKalmanScores(ssRun)

# Generate data based on model
fakeData <- mxGenerateData(ssRun, nrows=200)
# creates a numeric matrix with 200 rows and 5 columns
#  according to the model coefficients in ssRun


# Multisubject model
# Generate fake data from the original model
NumberOfSubjects <- 80
NumberOfTimepoints <- 100
dataL <- list()
beg <- Sys.time()
for(k in 1:NumberOfSubjects){dataL[[k]] <- mxGenerateData(ssModel, NumberOfTimepoints)}
end <- Sys.time()
end-beg
indivmodels <- list()
modNames <- paste("indiv", 1:NumberOfSubjects, sep="")

# Create multisubject model
for(k in 1:NumberOfSubjects){
	DataSetForSubjectK <- dataL[[k]]
	indivmodels[[k]] <- mxModel(name=modNames[k],
		amat, bmat, cmat, dmat, qmat, rmat, xmat, pmat, umat,
		mxExpectationStateSpace(A="A", B="B", C="C", D="D",
			Q="Q", R="R", x0="x0", P0="P0", u="u"),
		mxFitFunctionML(),
		mxData(DataSetForSubjectK, type='raw')) 
}
multiSubjModel <- mxModel(name="MultiMod", indivmodels,
	mxFitFunctionMultigroup(modNames))

# Run model and examine results
multiSubjRun <- mxRun(multiSubjModel)
summary(multiSubjRun)

# True generating paramters
omxGetParameters(ssModel)

# Estimated paramters from multisubject model with
#  80 individuals and 100 time points each
omxGetParameters(multiSubjRun)



