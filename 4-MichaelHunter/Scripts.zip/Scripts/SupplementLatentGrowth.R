#------------------------------------------------------------------------------
# Load required packages

require(OpenMx)

#------------------------------------------------------------------------------
# Read-in and list-ify data

data(myLongitudinalData)
matplot(t(myLongitudinalData), type='l')
dataL <- list()
for(i in 1:nrow(myLongitudinalData)){
	obsI <- unlist(myLongitudinalData[i,])
	dataL[[i]] <- data.frame(y=obsI, ID=i, time=0:4)
}
nSubj <- length(dataL)


#------------------------------------------------------------------------------
# Create state space matrices for latent growth

amat <- mxMatrix("Iden", 2, 2, name="A")
bmat <- mxMatrix("Zero", 2, 1, name="B")
clab <- c(NA, "data.time")
cdim <- list(c("y"), c("I", "S"))
cmat <- mxMatrix("Full", 1, 2, FALSE, c(1, NA), name="C",
    dimnames=cdim, labels=clab)
dmat <- mxMatrix("Zero", 1, 1, name="D")
qmat <- mxMatrix("Zero", 2, 2, name="Q")
rlab <- "resid"
rmat <- mxMatrix("Diag", 1, 1, TRUE, .2, name="R", labels=rlab)
xlab <- c("meanI", "meanS")
xmat <- mxMatrix("Full", 2, 1, TRUE, c(1, 1), name="x0", labels=xlab)
pval <- c(1, .5, 1)
plab <- c("varI", "covIS", "varS")
pmat <- mxMatrix("Symm", 2, 2, TRUE, pval, name="P0", plab, lbound=c(0, NA, 0))
umat <- mxMatrix("Zero", 1, 1, name="u")

modL <- list(amat, bmat, cmat, dmat, qmat, rmat, xmat,
	pmat, umat)
modNames <- paste0("Subject", 1:nSubj, "LatentGrowth")
expSS <- mxExpectationStateSpace(A="A", B="B", C="C", D="D",
	Q="Q", R="R", x0="x0", P0="P0", u="u")

#------------------------------------------------------------------------------
# Create/estimate multisubject model

indivmodels <- list()
for(k in 1:nSubj){
	DataSetForSubjectK <- dataL[[k]]
	indivmodels[[k]] <- mxModel(name=modNames[k],
		modL, expSS,
		mxFitFunctionML(),
		mxData(DataSetForSubjectK, type='raw')) 
}
multiSubjGrowth <- mxModel(name="MultiGrowth", indivmodels,
	mxFitFunctionMultigroup(modNames))

multiSubjGrowthRun <- mxRun(multiSubjGrowth)


#------------------------------------------------------------------------------
# Examine results

summary(multiSubjGrowthRun)

# Kalman Scores for Subject 1
ks <- mxKalmanScores(multiSubjGrowthRun$Subject1LatentGrowth, frontend=FALSE)

# These are equal to the empirical Bayes random effects estimates
#  from the nlme and lme4 packages
ks$xSmoothed


ksAll <- matrix(0, nrow=length(multiSubjGrowthRun$submodels), ncol=2)
for(i in 1:length(multiSubjGrowthRun$submodels)){
	ksAll[i,] <- mxKalmanScores(multiSubjGrowthRun$submodels[[i]], frontend=TRUE)$xSmoothed[1,]
}


#------------------------------------------------------------------------------
# Run the linear mixed effects model for comparison

require(lme4)
tallData <- do.call(rbind, dataL)
g <- lmer(y ~ 1 + time + (1 + time | ID), data=tallData, REML=FALSE)

gfix <- fixef(g)
gcov <- as.data.frame(VarCorr(g))$vcov

# run SEM demo/LatentGrowthCurveModel_MatrixRaw.R
require(EasyMx)
gm <- emxGrowthModel(model=1, data=myLongitudinalData, use=names(myLongitudinalData), times=0:4, run=TRUE)
gms <- mxFactorScores(gm, 'Regression')

cbind(SSM=coef(multiSubjGrowthRun), SEM=coef(gm), mixed=c(gcov[4], gfix, gcov[c(1,3,2)]))





ks$xSmoothed[1,]
t(t(ranef(g)$ID) + fixef(g))[1,]
gms[1,,1]

#gms[,1,1] - ksAll[,1]
table(round(gms[,1,1] - ksAll[,1], 5))
#gms[,2,1] - ksAll[,2]
table(round(gms[,2,1] - ksAll[,2],5))


cor(t(ranef(g)$ID)[1,], gms[,1,1])
plot(t(ranef(g)$ID)[1,], gms[,1,1], xlab='LME Random Effect', ylab='LGC Factor Score')
lm(t(ranef(g)$ID)[1,] ~ gms[,1,1])

