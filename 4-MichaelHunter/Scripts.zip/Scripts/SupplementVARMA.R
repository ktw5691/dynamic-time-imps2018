#------------------------------------------------------------------------------
# Load required packages

require(OpenMx)


#------------------------------------------------------------------------------
# Read in data

setwd('./Projects/OpenMx/StateSpaceModel/')

ds <- read.table('varma53.txt', header=TRUE)
ds <- ds[,1:3]

#------------------------------------------------------------------------------
# General setup

xdim <- 1 #number of latent variables
udim <- 1 #number of covariates
ydim <- 3*xdim #number of observed variables

arlag <- 4 # autoregressive lag
malag <- 3 #0 or 3 # moving average lag

maxlag <- max(c(arlag, malag+1))
blockxdim <- xdim*(maxlag+1)

#manifest and latent variable names
manNames <- paste('y', 1:ydim, sep='')
latNames <- paste('x', 1:xdim, sep='')


#------------------------------------------------------------------------------
# Block matrix setup

Ix <- diag(1, nrow=xdim)
Zx <- matrix(0, xdim, xdim)

# list of autoregressive matrices with random start values
Alist <- list()
for(i in 0:(maxlag-1)){
	if(i < arlag){
		Alist[[i+1]] <- matrix(runif(xdim*xdim, -1, 1), xdim, xdim)
	} else {
		Alist[[i+1]] <- Zx
	}
}

# list of moving average matrices with random start values
Mlist <- list()
for(i in 0:(maxlag-2)){
	if(i < malag){
		Mlist[[i+1]] <- matrix(runif(xdim*xdim, -1, 1), xdim, xdim)
	} else {
		Mlist[[i+1]] <- Zx
	}
}

# Build AR and MA matrices into needed block
#  state space dynamics A matrix
Mfull <- c(list(Ix), Mlist, list(Zx))
Afull <- c(Alist, list(Zx))


arBlock <- do.call(cbind, Afull)
maBlock <- do.call(cbind, Mfull)
idBlock <- cbind(
	diag(1, nrow=(maxlag-1)*xdim),
	matrix(0, nrow=(maxlag-1)*xdim, ncol=2*xdim))

Ablock <- rbind(arBlock, idBlock, maBlock)


#------------------------------------------------------------------------------
# Starting values and more block matrices

# starting factor loadings
#  1s and 0s are assumed fixed
facpat <- c(1, .9, .9)
startLoads <- matrix(facpat, ydim, xdim)
#startLoads <- matrix(c(facpat, rep(0, 2*(ydim-length(facpat))), facpat), ydim, xdim)

# starting factor variances and initial means
# 1s and 0s are assumed fixed
startVar <- diag(runif(xdim, 1.1, 1.8), xdim)
startMean <- matrix(0, xdim, 1)

startResid <- diag(runif(ydim, .1, .8), ydim)

Qblock <- matrix(0, nrow=blockxdim, ncol=blockxdim)
Qblock[1:xdim, 1:xdim] <- startVar
Cblock <- matrix(0, nrow=ydim, ncol=blockxdim)
Cblock[ , (blockxdim-xdim+1):blockxdim] <- startLoads

cdimnames <- list(manNames, c(paste(latNames, "_lag", rep(1:maxlag, each=xdim), sep=""), latNames))


#------------------------------------------------------------------------------
# OpenMx matrix and model specification


A <- mxMatrix("Full", blockxdim, blockxdim, values=Ablock, free=(Ablock!=0 & Ablock!=1), name='A', lbound=-3, ubound=3)
B <- mxMatrix("Zero", blockxdim, udim, name='B')
C <- mxMatrix("Full", ydim, blockxdim, values=Cblock, free=(Cblock!=0 & Cblock!=1), name='C', dimnames=cdimnames, ubound=10)
D <- mxMatrix("Zero", ydim, udim, name='D')
Q <- mxMatrix("Symm", blockxdim, blockxdim, values=vech(Qblock), free=(Qblock!=0 & Qblock!=1), name='Q', lbound=0, ubound=10)
R <- mxMatrix("Symm", ydim, ydim, values=vech(startResid), free=(startResid!=0), name='R', lbound=0)
x0 <- mxMatrix("Full", blockxdim, 1, value=startMean, free=FALSE, name='x0')
P0 <- mxMatrix("Symm", blockxdim, blockxdim, values=diag(1, blockxdim), name='P0')
u <- mxMatrix("Zero", udim, 1, name='u')


#------------------------------------------------------------------------------
# Run model

nameVARMA <- paste0('StateSpaceVARMA(', arlag, ",", malag, ")")
modelVARMA <- mxModel(
	name=nameVARMA,
	A, B, C, D, Q, R, x0, P0, u,
	mxData(observed=ds, type='raw'),
	mxExpectationStateSpace(A='A', B='B', C='C', D='D', Q='Q', R='R', x0='x0', P0='P0', u='u'),
	mxFitFunctionML()
)


runVARMA <- mxRun(modelVARMA)


#------------------------------------------------------------------------------
# Inspect model

summary(runVARMA)


# Check that the dynamics are stable
# If the complex magnitude (i.e., Mod) of the eigenvalues are less than 1
#  then the dynamics are stable.
Mod(eigen(mxEval(A, runVARMA))$values)
# Looks good.

